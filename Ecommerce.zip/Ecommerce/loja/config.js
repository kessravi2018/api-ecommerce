export const API = "http://localhost:3000",
             versao = "v1",
             loja = "5c253046a20fd9f4c44b47ff",
             baseImg = API + "/public/images/";
export const api = (process.env.PUBLIC_URL) ? "https://api.loja-teste.ampliee.com" : "http://localhost:3000";
export const versao = "v1";
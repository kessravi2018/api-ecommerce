module.exports = {
    host: "smtp.gmail.com",
    port: 465,
    auth: {
        user: "email",
        pass: "senha"
    }
};